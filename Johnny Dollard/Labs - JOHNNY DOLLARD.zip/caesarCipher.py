def cipher( x, dist ):
  ans = ""
  return ans;


print ( cipher("abcdef", 1) )
print ( cipher("abcdef", 2) )
print ( cipher("abcdef", 3) )
print ( cipher("dogcatpig", 1) )
print ( cipher("dogcatpig", 2) )
print ( cipher("dogcatpig", 3) )

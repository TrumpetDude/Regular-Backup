def flip_em( s ):
  #add in code to flip the names
  #and add in a comma between the flipped names
  return ""

print ( flip_em("aplus comp") )
print ( flip_em("comp aplus") )
print ( flip_em("ben sam") )
print ( flip_em("sally sue") )
print ( flip_em("big man") )
print ( flip_em("fat head") )



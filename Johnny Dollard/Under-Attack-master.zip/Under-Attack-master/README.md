# Under Attack
Please see the [Wiki](https://github.com/TrumpetDude/Under-Attack/wiki) for information on gameplay, mechanics, and what is done in the game.

Here is what I want to add in the near future: 

Instruction screen, highscore saving, a pause button, and a fix on the image when the player is infected for distinction between the player and a zombie..
